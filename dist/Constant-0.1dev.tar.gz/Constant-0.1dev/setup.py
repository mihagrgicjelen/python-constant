from distutils.core import setup

setup(
    name='Constant',
    version='0.1dev',
    packages=['constant',],
    license='Creative Commons Attribution-Noncommercial-Share Alike license',
    long_description=open('README.md').read(),
)