# python-constant
General purpose Constant class for Python apps
